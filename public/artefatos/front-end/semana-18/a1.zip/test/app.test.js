import test from 'node:test';import assert from 'node:assert/strict';import {soma} from '../src/app.js';test('soma valores',()=>assert.equal(soma(2,3),5))
