# Código — Pipeline de CI/CD para front-end

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`package.json`, `src/app.js`, `test/app.test.js`, `.github/workflows/ci.yml`.

## Dependências

Node.js 20+; GitHub Actions executa remotamente quando o repositório existir.

## Execução

`npm test && npm run lint && npm run build`; envie o diretório para um repositório GitHub para acionar o workflow.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

Os três scripts passam localmente; no GitHub, o job `validar` aparece para push e pull request.

> **Simulação técnica:** a integração depende de serviço externo ou conta não disponível neste computador; o fluxo e o tratamento de falhas estão implementados sem credenciais reais.
