# Código — Testes de performance no front-end

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`lighthouserc.cjs`, `index.html`, `package.json`.

## Dependências

Node.js 20+, Chrome/Chromium e `@lhci/cli`.

## Execução

`npm install && npm run audit` em ambiente com navegador suportado.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

O Lighthouse executa três medições e falha se a acessibilidade ficar abaixo do limite definido.

> **Simulação técnica:** a integração depende de serviço externo ou conta não disponível neste computador; o fluxo e o tratamento de falhas estão implementados sem credenciais reais.
