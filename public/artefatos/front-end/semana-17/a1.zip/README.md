# Código — Consumo de API de dados climáticos

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `app.js`.

## Dependências

Nenhuma dependência; requer acesso à internet para consulta real.

## Execução

Abra `index.html` por um servidor local e clique em Buscar.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

A cidade retorna temperatura atual ou uma mensagem de erro tratada.

> **Simulação técnica:** a integração depende de serviço externo ou conta não disponível neste computador; o fluxo e o tratamento de falhas estão implementados sem credenciais reais.
