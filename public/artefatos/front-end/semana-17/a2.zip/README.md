# Código — Chat com WebSocket

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `app.js`.

## Dependências

Nenhuma dependência; o endpoint de eco é externo e pode ficar indisponível.

## Execução

Abra `index.html` em servidor local; envie uma mensagem quando o status for Conectado.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

A mensagem é exibida localmente e retornada pelo servidor de eco, ou o estado de falha é mostrado.

> **Simulação técnica:** a integração depende de serviço externo ou conta não disponível neste computador; o fluxo e o tratamento de falhas estão implementados sem credenciais reais.
