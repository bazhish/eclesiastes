# Código — Consultas GraphQL no front-end

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `app.js`.

## Dependências

Nenhuma dependência; API GraphQL pública usada apenas para demonstração.

## Execução

Abra `index.html` em servidor local e use o botão.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

A lista mostra nome e status, sem baixar campos não solicitados.

> **Simulação técnica:** a integração depende de serviço externo ou conta não disponível neste computador; o fluxo e o tratamento de falhas estão implementados sem credenciais reais.
