# Código — CSS Grid e layouts responsivos

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `styles.css`, `app.js`.

## Dependências

Nenhuma dependência externa.

## Execução

Abra `index.html` no navegador ou use `npx serve .`.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

Em tela maior há menu lateral; em 768 px ou menos o menu não aparece e o conteúdo ocupa uma coluna.
