'use strict'
console.info('Layout responsivo carregado.')
