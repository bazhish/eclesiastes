# Código — Prettier, ESLint e Babel

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`package.json`, `.prettierrc.json`, `eslint.config.js`, `babel.config.json`, `index.js`.

## Dependências

Node.js 20+; execute `npm install` para instalar Prettier, ESLint e Babel.

## Execução

`npm install && npm run format && npm run lint && npm run build && node index.compilado.js`.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

O lint termina sem erros; `index.compilado.js` é criado; o console mostra `Olá, Desenvolvedor!`.
