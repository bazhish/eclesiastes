export default [{files:['**/*.js'],languageOptions:{ecmaVersion:2022},rules:{quotes:['error','single'],semi:['error','never']}}]
