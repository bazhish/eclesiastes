# Código — Performance: Lazy Loading e minificação

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `styles.css`, `postcss.config.cjs`, `package.json`.

## Dependências

Node.js 20+ para minificação; imagens externas apenas para demonstração.

## Execução

`npm install && npm run build:css`; depois abra `index.html` com um servidor local.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

`styles.min.css` é gerado e as imagens possuem o atributo `loading="lazy"`.

> **Simulação técnica:** a integração depende de serviço externo ou conta não disponível neste computador; o fluxo e o tratamento de falhas estão implementados sem credenciais reais.
