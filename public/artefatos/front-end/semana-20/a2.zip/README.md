# Código — Animações e interações avançadas

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `styles.css`, `app.js`.

## Dependências

Nenhuma dependência externa.

## Execução

Abra `index.html` e acione Mostrar detalhe; habilite redução de movimento no sistema para conferir a alternativa.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

O detalhe aparece e o cartão se move suavemente, ou sem transição quando a preferência reduzida está ativa.
