# Código — Testes automatizados de acessibilidade

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `package.json`, `a11y.spec.js`.

## Dependências

Node.js 20+, navegadores Playwright e pacotes listados.

## Execução

`npm install && npx playwright install && npm run test:a11y`.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

O teste conclui sem violações automáticas para a página de exemplo; uma auditoria do portal real exige URL e autorização de acesso.

> **Simulação técnica:** a integração depende de serviço externo ou conta não disponível neste computador; o fluxo e o tratamento de falhas estão implementados sem credenciais reais.
