# Código — Acessibilidade em aplicações web

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `styles.css`, `app.js`.

## Dependências

Nenhuma dependência; WAVE é serviço externo de auditoria.

## Execução

Abra `index.html`, navegue apenas com Tab e acione Enviar.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

O foco é visível, o rótulo é anunciado e a mensagem dinâmica pode ser lida por tecnologia assistiva.
