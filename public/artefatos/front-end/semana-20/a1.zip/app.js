document.querySelector('#enviar').onclick=()=>document.querySelector('#aviso').textContent='Mensagem enviada para validação local.'
