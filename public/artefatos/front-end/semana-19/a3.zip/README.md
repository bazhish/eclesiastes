# Código — Gerenciamento de estado com Redux

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `app.js`.

## Dependências

Nenhuma dependência no exemplo didático; em projeto React use Redux Toolkit conforme documentação oficial.

## Execução

Abra `index.html` e clique em Incrementar.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

O valor aumenta e a interface reflete o estado da store.
