# Código — Perfil de usuário com CSS moderno

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `styles.css`.

## Dependências

Nenhuma dependência externa.

## Execução

Abra `index.html` e altere a largura da janela em 960 px.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

A grade tem uma coluna no celular e três colunas em 960 px ou mais.
