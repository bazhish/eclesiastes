# Código — Página Mobile-First

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `styles.css`.

## Dependências

Nenhuma dependência; imagem remota é demonstrativa.

## Execução

Abra `index.html`; compare a disposição abaixo e acima de 768 px.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

O conteúdo fica empilhado no celular e lado a lado no desktop.

> **Simulação técnica:** a integração depende de serviço externo ou conta não disponível neste computador; o fluxo e o tratamento de falhas estão implementados sem credenciais reais.
