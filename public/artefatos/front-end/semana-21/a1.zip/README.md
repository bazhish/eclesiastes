# Código — Integração com autenticação

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `app.js`, `.env.example`.

## Dependências

Nenhuma credencial é incluída. Para fluxo real, registrar aplicação no Google Cloud e validar tokens em backend seguro.

## Execução

Copie `.env.example` para o mecanismo de ambiente do projeto e preencha apenas valores públicos autorizados.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

Sem configuração, a tela informa o requisito; com configuração válida, o aplicativo pode iniciar o redirecionamento OAuth.

> **Simulação técnica:** a integração depende de serviço externo ou conta não disponível neste computador; o fluxo e o tratamento de falhas estão implementados sem credenciais reais.
