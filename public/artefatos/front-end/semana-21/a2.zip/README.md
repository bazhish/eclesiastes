# Código — Monitoramento e logs para front-end

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `app.js`, `.env.example`.

## Dependências

Nenhuma conta ou DSN real. Serviço de monitoramento é opcional e externo.

## Execução

Abra `index.html`, clique em Simular erro e confira o console do navegador.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

Um evento estruturado é exibido no console e a interface confirma o registro local.

> **Simulação técnica:** a integração depende de serviço externo ou conta não disponível neste computador; o fluxo e o tratamento de falhas estão implementados sem credenciais reais.
