# Código — Animações com CSS, JavaScript e GSAP

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `styles.css`, `app.js`.

## Dependências

Nenhuma instalação para a demonstração; GSAP é carregado por CDN.

## Execução

Abra `index.html`; para funcionamento sem internet, instale GSAP localmente e troque a referência CDN.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

O formulário entra animado e, ao enviar campos válidos, mostra a confirmação local.

> **Simulação técnica:** a integração depende de serviço externo ou conta não disponível neste computador; o fluxo e o tratamento de falhas estão implementados sem credenciais reais.
