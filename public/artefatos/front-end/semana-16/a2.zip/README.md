# Código — Pré-processadores CSS com SCSS

## Linguagem e versão

HTML5, CSS3 e JavaScript ECMAScript 2022; quando indicado, Node.js 20+.

## Arquivos

`index.html`, `styles.scss`, `package.json`.

## Dependências

Node.js 20+ e pacote `sass`.

## Execução

`npm install && npm run build`; abra `index.html` após vincular `styles.css` no lugar de `styles.css` se necessário.

## Teste

Abra a página, execute a interação descrita no gabarito e confira o comportamento no navegador. Para os projetos com `package.json`, execute também `npm test` quando o comando estiver definido.

## Resultado esperado

O comando gera `styles.css`; o cartão e botão usam a paleta definida uma única vez em SCSS.
