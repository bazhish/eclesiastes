-- MySQL 8.0+: cenário isolado para as operações CRUD pedidas.
CREATE DATABASE IF NOT EXISTS techsolutions_crud;
USE techsolutions_crud;

CREATE TABLE IF NOT EXISTS fornecedores (
    id_fornecedor INT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    contato VARCHAR(120) NOT NULL,
    endereco VARCHAR(200) NOT NULL
);

CREATE TABLE IF NOT EXISTS vendas (
    id_venda INT PRIMARY KEY,
    id_cliente INT NOT NULL,
    data_venda DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS itens_venda (
    id_item_venda INT PRIMARY KEY AUTO_INCREMENT,
    id_venda INT NOT NULL,
    id_produto INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_item_venda
        FOREIGN KEY (id_venda) REFERENCES vendas(id_venda)
);

INSERT INTO vendas (id_venda, id_cliente, data_venda)
VALUES (301, 101, '2026-08-01'), (302, 101, '2026-08-10'), (303, 102, '2026-08-12')
ON DUPLICATE KEY UPDATE id_cliente = VALUES(id_cliente), data_venda = VALUES(data_venda);

INSERT INTO itens_venda (id_venda, id_produto, quantidade, preco_unitario)
SELECT 301, 10, 2, 59.90 WHERE NOT EXISTS (
    SELECT 1 FROM itens_venda WHERE id_venda = 301 AND id_produto = 10
);
INSERT INTO itens_venda (id_venda, id_produto, quantidade, preco_unitario)
SELECT 302, 11, 1, 120.00 WHERE NOT EXISTS (
    SELECT 1 FROM itens_venda WHERE id_venda = 302 AND id_produto = 11
);

-- 4.1 SELECT: vendas do cliente 101.
SELECT v.id_venda, v.data_venda, iv.id_produto, iv.quantidade, iv.preco_unitario
FROM vendas AS v
LEFT JOIN itens_venda AS iv ON iv.id_venda = v.id_venda
WHERE v.id_cliente = 101
ORDER BY v.data_venda, v.id_venda;

-- 4.2 INSERT: novo fornecedor.
INSERT INTO fornecedores (id_fornecedor, nome, contato, endereco)
VALUES (201, 'GlobalTech', 'contato@globaltech.com', 'Av. das Indústrias, 500')
ON DUPLICATE KEY UPDATE
    nome = VALUES(nome), contato = VALUES(contato), endereco = VALUES(endereco);

-- 4.3 UPDATE: correção do endereço do fornecedor 201.
UPDATE fornecedores
SET endereco = 'Av. das Indústrias, 550'
WHERE id_fornecedor = 201;

-- 4.4 DELETE: exclusão da venda cancelada e de seus itens, em transação.
START TRANSACTION;
DELETE FROM itens_venda WHERE id_venda = 303;
DELETE FROM vendas WHERE id_venda = 303;
COMMIT;

-- Verificações finais.
SELECT * FROM fornecedores WHERE id_fornecedor = 201;
SELECT * FROM vendas WHERE id_venda = 303;
