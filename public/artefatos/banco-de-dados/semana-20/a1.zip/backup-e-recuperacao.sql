# Execute a parte SQL no cliente mysql; os comandos mysqldump/mysql abaixo são de terminal.
DROP DATABASE IF EXISTS LojaXYZ;
CREATE DATABASE LojaXYZ CHARACTER SET utf8mb4;
USE LojaXYZ;
CREATE TABLE Clientes(id_cliente INT PRIMARY KEY,nome VARCHAR(100),email VARCHAR(150));
CREATE TABLE Produtos(id_produto INT PRIMARY KEY,nome_produto VARCHAR(100),preco DECIMAL(10,2));
CREATE TABLE Pedidos(id_pedido INT PRIMARY KEY,id_cliente INT NOT NULL,id_produto INT NOT NULL,data_pedido DATE,
  FOREIGN KEY(id_cliente) REFERENCES Clientes(id_cliente),FOREIGN KEY(id_produto) REFERENCES Produtos(id_produto));
CREATE TABLE Fornecedores(id_fornecedor INT PRIMARY KEY,nome_fornecedor VARCHAR(100),telefone VARCHAR(30));
INSERT INTO Clientes VALUES(1,'Ana','ana@exemplo.com'),(2,'Bruno','bruno@exemplo.com'),(3,'Carla','carla@exemplo.com'),(4,'Diego','diego@exemplo.com'),(5,'Elisa','elisa@exemplo.com');
INSERT INTO Produtos VALUES(1,'Mouse',90),(2,'Teclado',180),(3,'Monitor',1200),(4,'Webcam',250),(5,'Cabo',30);
INSERT INTO Fornecedores VALUES(1,'GlobalTech','11999990001'),(2,'DataPlus','11999990002'),(3,'Comercial Sul','11999990003'),(4,'Norte Digital','11999990004'),(5,'EletroMax','11999990005');
INSERT INTO Pedidos VALUES(1,1,1,'2026-01-01'),(2,2,2,'2026-01-02'),(3,3,3,'2026-01-03'),(4,4,4,'2026-01-04'),(5,5,5,'2026-01-05');
-- Terminal: mysqldump -u SEU_USUARIO -p LojaXYZ > backup_lojaXYZ.sql
DELETE FROM Pedidos;
-- Terminal: mysql -u SEU_USUARIO -p LojaXYZ < backup_lojaXYZ.sql
CREATE TABLE NovosProdutos(id_produto INT PRIMARY KEY,nome VARCHAR(100),preco DECIMAL(10,2));
INSERT INTO NovosProdutos VALUES(6,'Headset',320),(7,'Hub USB',110);
-- Terminal: mysqldump -u SEU_USUARIO -p LojaXYZ NovosProdutos > backup_incremental.sql
DROP TABLE NovosProdutos;
-- Terminal: mysql -u SEU_USUARIO -p LojaXYZ < backup_incremental.sql
