DROP DATABASE IF EXISTS seguranca_a3; CREATE DATABASE seguranca_a3 CHARACTER SET utf8mb4; USE seguranca_a3;
CREATE TABLE customers(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARBINARY(255) NOT NULL,phone_number VARBINARY(255) NOT NULL);
SET @chave_demo='NUNCA_USAR_EM_PRODUCAO';
INSERT INTO customers(name,email,phone_number) VALUES
  ('João Silva',AES_ENCRYPT('joao@exemplo.com',@chave_demo),AES_ENCRYPT('11999990001',@chave_demo)),
  ('Maria Souza',AES_ENCRYPT('maria@exemplo.com',@chave_demo),AES_ENCRYPT('11999990002',@chave_demo)),
  ('Carlos Lima',AES_ENCRYPT('carlos@exemplo.com',@chave_demo),AES_ENCRYPT('11999990003',@chave_demo));
SELECT name,CAST(AES_DECRYPT(email,@chave_demo) AS CHAR(150)) AS email,CAST(AES_DECRYPT(phone_number,@chave_demo) AS CHAR(30)) AS telefone FROM customers;
CREATE USER IF NOT EXISTS 'admin'@'localhost' IDENTIFIED BY 'TROCAR_POR_SEGREDO_FORTE';
CREATE USER IF NOT EXISTS 'view_only'@'localhost' IDENTIFIED BY 'TROCAR_POR_SEGREDO_FORTE';
GRANT ALL PRIVILEGES ON seguranca_a3.customers TO 'admin'@'localhost'; GRANT SELECT ON seguranca_a3.customers TO 'view_only'@'localhost';
SHOW GRANTS FOR 'admin'@'localhost'; SHOW GRANTS FOR 'view_only'@'localhost';
-- Requer privilégio administrativo; escolha caminho seguro conforme o sistema operacional.
SET GLOBAL general_log = 'ON';
