-- Executar em uma instância de teste do MySQL.
SHOW VARIABLES LIKE 'slow_query_log'; SHOW VARIABLES LIKE 'long_query_time';
SHOW GLOBAL STATUS LIKE 'Threads_connected'; SHOW GLOBAL STATUS LIKE 'Questions';
SHOW FULL PROCESSLIST;
SHOW ENGINE INNODB STATUS;
EXPLAIN ANALYZE SELECT * FROM pedidos WHERE id_cliente=101 AND data_pedido>='2026-01-01';
SHOW INDEX FROM pedidos;
-- Exemplo de índice somente após confirmar a necessidade com EXPLAIN:
CREATE INDEX idx_pedidos_cliente_data ON pedidos(id_cliente,data_pedido);
