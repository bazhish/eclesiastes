DROP DATABASE IF EXISTS integridade_a1;
CREATE DATABASE integridade_a1 CHARACTER SET utf8mb4;
USE integridade_a1;
CREATE TABLE clientes (
  id_cliente INT PRIMARY KEY, nome VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE, telefone VARCHAR(30)
) ENGINE=InnoDB;
CREATE TABLE produtos (
  id_produto INT PRIMARY KEY, nome_do_produto VARCHAR(100) NOT NULL,
  preco DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB;
CREATE TABLE pedidos (
  id_pedido INT PRIMARY KEY, data_do_pedido DATE NOT NULL,
  valor_total DECIMAL(10,2) NOT NULL, id_cliente INT NOT NULL,
  CONSTRAINT fk_pedido_cliente FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
    ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;
CREATE TABLE itens_pedido (
  id_item INT PRIMARY KEY, id_pedido INT NOT NULL, id_produto INT NOT NULL,
  quantidade INT NOT NULL CHECK (quantidade > 0),
  FOREIGN KEY (id_pedido) REFERENCES pedidos(id_pedido) ON DELETE CASCADE,
  FOREIGN KEY (id_produto) REFERENCES produtos(id_produto) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;
INSERT INTO clientes VALUES
  (1,'Ana Lima','ana@exemplo.com','11999990001'),(2,'Bruno Reis','bruno@exemplo.com','11999990002'),(3,'Carla Souza','carla@exemplo.com','11999990003');
INSERT INTO produtos VALUES
  (1,'Notebook',3500),(2,'Mouse',90),(3,'Teclado',180),(4,'Monitor',1200),(5,'Webcam',250);
INSERT INTO pedidos VALUES (10,'2026-08-01',3590,1),(11,'2026-08-02',1450,2);
INSERT INTO itens_pedido VALUES (100,10,1,1),(101,10,2,1),(102,11,4,1),(103,11,5,1);
SELECT pe.id_pedido, c.nome, p.nome_do_produto, i.quantidade
FROM pedidos pe JOIN clientes c ON c.id_cliente=pe.id_cliente
  JOIN itens_pedido i ON i.id_pedido=pe.id_pedido JOIN produtos p ON p.id_produto=i.id_produto;
-- Esperado: erro de chave estrangeira; o cliente 1 ainda possui o pedido 10.
DELETE FROM clientes WHERE id_cliente = 1;
