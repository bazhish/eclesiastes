DROP DATABASE IF EXISTS transacoes_a3;
CREATE DATABASE transacoes_a3 CHARACTER SET utf8mb4;
USE transacoes_a3;
CREATE TABLE pedidos (
  id INT AUTO_INCREMENT PRIMARY KEY, cliente VARCHAR(100) NOT NULL,
  produto VARCHAR(100) NOT NULL, quantidade INT NOT NULL CHECK (quantidade > 0),
  valor DECIMAL(10,2) NOT NULL CHECK (valor >= 0), status VARCHAR(20) DEFAULT 'Pendente'
) ENGINE=InnoDB;
START TRANSACTION;
INSERT INTO pedidos (cliente,produto,quantidade,valor) VALUES ('João Silva','Notebook',1,3500.00);
ROLLBACK;
START TRANSACTION;
INSERT INTO pedidos (cliente,produto,quantidade,valor) VALUES ('Maria Souza','Smartphone',2,2000.00);
COMMIT;
START TRANSACTION;
INSERT INTO pedidos (cliente,produto,quantidade,valor) VALUES ('Carlos Lima','Tablet',1,1500.00);
-- Simulação de erro de validação: quantidade negativa viola CHECK.
INSERT INTO pedidos (cliente,produto,quantidade,valor) VALUES ('Falha','Smartwatch',-1,500.00);
ROLLBACK;
SELECT * FROM pedidos; -- Esperado: somente o pedido confirmado de Maria.
