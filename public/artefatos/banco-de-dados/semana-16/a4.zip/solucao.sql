DROP DATABASE IF EXISTS vistas_a4;
CREATE DATABASE vistas_a4 CHARACTER SET utf8mb4;
USE vistas_a4;
CREATE TABLE clientes (id INT AUTO_INCREMENT PRIMARY KEY,nome VARCHAR(100),email VARCHAR(100)) ENGINE=InnoDB;
CREATE TABLE produtos (id INT AUTO_INCREMENT PRIMARY KEY,nome VARCHAR(100),preco DECIMAL(10,2)) ENGINE=InnoDB;
CREATE TABLE vendas (id INT AUTO_INCREMENT PRIMARY KEY,id_cliente INT,id_produto INT,data_venda DATE,quantidade INT,
  FOREIGN KEY(id_cliente) REFERENCES clientes(id),FOREIGN KEY(id_produto) REFERENCES produtos(id)) ENGINE=InnoDB;
INSERT INTO clientes(nome,email) VALUES ('Ana','ana@exemplo.com'),('Bruno','bruno@exemplo.com');
INSERT INTO produtos(nome,preco) VALUES ('Teclado',180),('Cabo',30),('Monitor',1200);
INSERT INTO vendas(id_cliente,id_produto,data_venda,quantidade) VALUES (1,1,'2026-08-01',12),(1,2,'2026-08-02',2),(2,3,'2026-08-03',1);
CREATE VIEW relatorio_vendas AS
  SELECT c.nome AS cliente,p.nome AS produto,v.data_venda,v.quantidade FROM vendas v
  JOIN clientes c ON c.id=v.id_cliente JOIN produtos p ON p.id=v.id_produto;
SELECT * FROM relatorio_vendas;
SELECT * FROM relatorio_vendas WHERE quantidade > 10;
CREATE TABLE relatorio_vendas_materializada AS
  SELECT c.nome AS cliente,p.nome AS produto,v.data_venda,v.quantidade,p.preco FROM vendas v
  JOIN clientes c ON c.id=v.id_cliente JOIN produtos p ON p.id=v.id_produto WHERE p.preco > 100;
SELECT * FROM relatorio_vendas_materializada;
DROP TABLE relatorio_vendas_materializada;
CREATE TABLE relatorio_vendas_materializada AS
  SELECT c.nome AS cliente,p.nome AS produto,v.data_venda,v.quantidade,p.preco FROM vendas v
  JOIN clientes c ON c.id=v.id_cliente JOIN produtos p ON p.id=v.id_produto WHERE p.preco > 100;
