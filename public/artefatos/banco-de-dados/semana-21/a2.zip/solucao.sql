DROP DATABASE IF EXISTS TechTradeDB; CREATE DATABASE TechTradeDB CHARACTER SET utf8mb4; USE TechTradeDB;
CREATE TABLE produtos(id_produto INT PRIMARY KEY,nome_produto VARCHAR(100),categoria VARCHAR(100),preco DECIMAL(10,2));
CREATE TABLE clientes(id_cliente INT PRIMARY KEY,nome_cliente VARCHAR(100),cidade VARCHAR(100),estado CHAR(2));
CREATE TABLE vendas(
  id_venda INT NOT NULL,id_produto INT NOT NULL,id_cliente INT NOT NULL,data_venda DATE NOT NULL,quantidade INT NOT NULL,valor_total DECIMAL(10,2) NOT NULL,
  PRIMARY KEY(id_venda,data_venda), KEY idx_produto_data(id_produto,data_venda)
) ENGINE=InnoDB
PARTITION BY RANGE COLUMNS(data_venda)(
  PARTITION p2022 VALUES LESS THAN ('2023-01-01'),PARTITION p2023 VALUES LESS THAN ('2024-01-01'),
  PARTITION p2024 VALUES LESS THAN ('2025-01-01'),PARTITION pmax VALUES LESS THAN (MAXVALUE)
);
INSERT INTO produtos VALUES(101,'Notebook','Informática',3500); INSERT INTO clientes VALUES(1,'Ana','São Paulo','SP');
INSERT INTO vendas VALUES(1,101,1,'2024-06-10',1,3500),(2,101,1,'2024-11-10',1,3500);
EXPLAIN SELECT * FROM vendas WHERE id_produto=101 AND data_venda BETWEEN '2024-01-01' AND '2024-12-31';
