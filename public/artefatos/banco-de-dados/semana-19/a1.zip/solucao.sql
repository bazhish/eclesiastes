DROP DATABASE IF EXISTS FastShop; CREATE DATABASE FastShop CHARACTER SET utf8mb4; USE FastShop;
CREATE TABLE Produto (id_produto INT AUTO_INCREMENT PRIMARY KEY,nome VARCHAR(100) NOT NULL,preco DECIMAL(10,2) NOT NULL,estoque INT NOT NULL);
CREATE TABLE Cliente (id_cliente INT AUTO_INCREMENT PRIMARY KEY,nome VARCHAR(100) NOT NULL,email VARCHAR(100) NOT NULL UNIQUE,telefone VARCHAR(15));
CREATE TABLE Pedido (id_pedido INT AUTO_INCREMENT PRIMARY KEY,id_cliente INT NOT NULL,data_pedido DATE NOT NULL,total DECIMAL(10,2) NOT NULL,FOREIGN KEY(id_cliente) REFERENCES Cliente(id_cliente));
ALTER TABLE Produto ADD COLUMN descricao VARCHAR(255); ALTER TABLE Cliente DROP COLUMN telefone; DROP TABLE Pedido;
INSERT INTO Produto(nome,preco,estoque,descricao) VALUES ('Mouse',90,10,'Mouse sem fio'),('Teclado',180,8,'Teclado mecânico'),('Monitor',1200,4,'Monitor 27');
INSERT INTO Cliente(nome,email) VALUES ('Ana','ana@exemplo.com'),('Bruno','bruno@exemplo.com');
UPDATE Produto SET preco=95 WHERE nome='Mouse'; UPDATE Cliente SET nome='Bruno Reis' WHERE email='bruno@exemplo.com';
DELETE FROM Produto WHERE nome='Teclado'; DELETE FROM Cliente WHERE email='ana@exemplo.com';
