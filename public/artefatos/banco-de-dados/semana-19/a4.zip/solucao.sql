DROP DATABASE IF EXISTS transacao_dml_a4; CREATE DATABASE transacao_dml_a4 CHARACTER SET utf8mb4; USE transacao_dml_a4;
CREATE TABLE Clientes(id_cliente INT AUTO_INCREMENT PRIMARY KEY,nome VARCHAR(100),email VARCHAR(100) UNIQUE,endereco VARCHAR(255)) ENGINE=InnoDB;
CREATE TABLE Produtos(id_produto INT PRIMARY KEY,nome VARCHAR(100) NOT NULL,preco DECIMAL(10,2) NOT NULL) ENGINE=InnoDB;
CREATE TABLE Pedidos(id_pedido INT AUTO_INCREMENT PRIMARY KEY,id_cliente INT NOT NULL,data_pedido DATE,status VARCHAR(20),FOREIGN KEY(id_cliente) REFERENCES Clientes(id_cliente)) ENGINE=InnoDB;
CREATE TABLE Itens_Pedido(id_item INT AUTO_INCREMENT PRIMARY KEY,id_pedido INT NOT NULL,id_produto INT NOT NULL,quantidade INT NOT NULL,preco DECIMAL(10,2) NOT NULL,FOREIGN KEY(id_pedido) REFERENCES Pedidos(id_pedido),FOREIGN KEY(id_produto) REFERENCES Produtos(id_produto)) ENGINE=InnoDB;
INSERT INTO Produtos VALUES(101,'Produto físico',299.90),(102,'Produto digital',49.90);
DELIMITER //
CREATE PROCEDURE processar_pedido_carlos()
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
  START TRANSACTION;
  INSERT INTO Clientes(nome,email,endereco) VALUES('Carlos Mendes','carlos@email.com','Rua das Flores, 789');
  SET @cliente_id=LAST_INSERT_ID();
  INSERT INTO Pedidos(id_cliente,data_pedido,status) VALUES(@cliente_id,'2024-11-10','Em Processamento');
  SET @pedido_id=LAST_INSERT_ID();
  INSERT INTO Itens_Pedido(id_pedido,id_produto,quantidade,preco) VALUES(@pedido_id,101,2,299.90),(@pedido_id,102,1,49.90);
  COMMIT;
END//
DELIMITER ;
CALL processar_pedido_carlos();
