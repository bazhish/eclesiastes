DROP DATABASE IF EXISTS janelas_a1;
CREATE DATABASE janelas_a1 CHARACTER SET utf8mb4;
USE janelas_a1;
CREATE TABLE vendas (
  id_venda INT PRIMARY KEY, data_venda DATE NOT NULL, produto VARCHAR(100) NOT NULL,
  vendedor VARCHAR(100) NOT NULL, quantidade INT NOT NULL, valor_total DECIMAL(10,2) NOT NULL
);
INSERT INTO vendas VALUES
  (1,'2026-01-02','Notebook','Ana',1,3500),(2,'2026-01-03','Mouse','Bruno',3,270),
  (3,'2026-01-05','Notebook','Ana',1,3300),(4,'2026-01-07','Monitor','Carla',1,1200),
  (5,'2026-01-09','Mouse','Ana',5,450),(6,'2026-01-10','Teclado','Bruno',2,360),
  (7,'2026-01-12','Monitor','Carla',2,2400),(8,'2026-01-14','Notebook','Bruno',1,3700),
  (9,'2026-01-15','Teclado','Ana',1,180),(10,'2026-01-17','Mouse','Carla',1,90);
SELECT id_venda,data_venda,produto,vendedor,
  ROW_NUMBER() OVER (ORDER BY data_venda DESC) AS numero_venda FROM vendas;
SELECT id_venda,data_venda,produto,vendedor,
  ROW_NUMBER() OVER (PARTITION BY vendedor ORDER BY data_venda DESC) AS numero_por_vendedor FROM vendas;
WITH vendas_ordenadas AS (
  SELECT *,ROW_NUMBER() OVER (PARTITION BY produto ORDER BY valor_total DESC,id_venda) AS posicao FROM vendas
) SELECT id_venda,produto,vendedor,valor_total FROM vendas_ordenadas WHERE posicao=1;
