DROP DATABASE IF EXISTS case_a4;
CREATE DATABASE case_a4 CHARACTER SET utf8mb4;
USE case_a4;
CREATE TABLE clientes (id_cliente INT PRIMARY KEY,nome VARCHAR(100));
CREATE TABLE vendedores (id_vendedor INT PRIMARY KEY,nome VARCHAR(100));
CREATE TABLE produtos (id_produto INT PRIMARY KEY,nome VARCHAR(100),preco DECIMAL(10,2));
CREATE TABLE vendas (id_venda INT PRIMARY KEY,id_cliente INT,id_vendedor INT,valor DECIMAL(10,2));
INSERT INTO clientes VALUES(1,'Ana'),(2,'Bruno'); INSERT INTO vendedores VALUES(1,'Carla'),(2,'Diego');
INSERT INTO produtos VALUES(1,'Monitor',1200),(2,'Teclado',80),(3,'Cabo',20);
INSERT INTO vendas VALUES(1,1,1,1200),(2,1,1,9000),(3,2,2,700),(4,2,2,4000);
SELECT c.nome,v.valor,CASE WHEN v.valor>1000 THEN 'Alta' WHEN v.valor>=500 THEN 'Média' ELSE 'Baixa' END AS categoria_venda
  FROM vendas v JOIN clientes c ON c.id_cliente=v.id_cliente;
SELECT ve.nome,SUM(v.valor) total_vendas,CASE WHEN SUM(v.valor)>10000 THEN 'Excelente' WHEN SUM(v.valor)>=5000 THEN 'Bom' ELSE 'Regular' END AS desempenho
  FROM vendedores ve JOIN vendas v ON v.id_vendedor=ve.id_vendedor GROUP BY ve.id_vendedor,ve.nome;
SELECT nome,preco,CASE WHEN preco>100 THEN 'Caro' WHEN preco>=50 THEN 'Moderado' ELSE 'Barato' END AS categoria_preco FROM produtos;
