DROP DATABASE IF EXISTS uniao_a3;
CREATE DATABASE uniao_a3 CHARACTER SET utf8mb4;
USE uniao_a3;
CREATE TABLE clientes (id INT PRIMARY KEY,nome VARCHAR(100),cidade VARCHAR(100),email VARCHAR(150));
CREATE TABLE fornecedores (id INT PRIMARY KEY,nome VARCHAR(100),cidade VARCHAR(100),email VARCHAR(150));
INSERT INTO clientes VALUES (1,'João Silva','São Paulo','joao@email.com'),(2,'Maria Santos','Rio de Janeiro','maria@email.com'),(3,'Pedro Lima','São Paulo','pedro@email.com');
INSERT INTO fornecedores VALUES (1,'João Silva','São Paulo','joao@fornece.com'),(4,'Ana Costa','Salvador','ana@fornece.com'),(5,'Carlos Nunes','Recife','carlos@fornece.com');
SELECT nome FROM clientes UNION SELECT nome FROM fornecedores;
SELECT nome FROM clientes UNION ALL SELECT nome FROM fornecedores;
SELECT COUNT(*) AS total_linhas FROM (SELECT nome,email FROM clientes UNION ALL SELECT nome,email FROM fornecedores) AS contatos;
SELECT nome,COUNT(*) AS ocorrencias FROM (SELECT nome FROM clientes UNION ALL SELECT nome FROM fornecedores) AS nomes
  GROUP BY nome HAVING COUNT(*) > 1;
