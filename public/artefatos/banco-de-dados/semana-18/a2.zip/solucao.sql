DROP DATABASE IF EXISTS cte_a2;
CREATE DATABASE cte_a2 CHARACTER SET utf8mb4;
USE cte_a2;
CREATE TABLE funcionarios (
  id_funcionario INT PRIMARY KEY,nome VARCHAR(100) NOT NULL,id_supervisor INT NULL,
  FOREIGN KEY(id_supervisor) REFERENCES funcionarios(id_funcionario)
) ENGINE=InnoDB;
CREATE TABLE vendas (id_venda INT PRIMARY KEY,id_funcionario INT NOT NULL,valor_venda DECIMAL(10,2) NOT NULL,data_venda DATE NOT NULL,
  FOREIGN KEY(id_funcionario) REFERENCES funcionarios(id_funcionario)) ENGINE=InnoDB;
INSERT INTO funcionarios VALUES (1,'Alice',NULL),(2,'Bruno',1),(3,'Carla',1),(4,'Diego',2),(5,'Elisa',2);
INSERT INTO vendas VALUES (1,1,1000,'2026-01-01'),(2,2,800,'2026-01-02'),(3,2,400,'2026-01-03'),(4,3,1200,'2026-01-04'),
  (5,4,500,'2026-01-05'),(6,4,700,'2026-01-06'),(7,5,300,'2026-01-07'),(8,3,600,'2026-01-08');
WITH total_vendas AS (SELECT id_funcionario,SUM(valor_venda) total FROM vendas GROUP BY id_funcionario)
SELECT f.nome,COALESCE(t.total,0) AS total_vendas FROM funcionarios f LEFT JOIN total_vendas t ON t.id_funcionario=f.id_funcionario;
WITH RECURSIVE hierarquia AS (
  SELECT id_funcionario,nome,id_supervisor,1 nivel,CAST(nome AS CHAR(500)) caminho FROM funcionarios WHERE id_supervisor IS NULL
  UNION ALL
  SELECT f.id_funcionario,f.nome,f.id_supervisor,h.nivel+1,CONCAT(h.caminho,' > ',f.nome)
  FROM funcionarios f JOIN hierarquia h ON f.id_supervisor=h.id_funcionario
) SELECT * FROM hierarquia ORDER BY caminho;
WITH RECURSIVE descendentes AS (
  SELECT id_funcionario AS supervisor,id_funcionario AS descendente FROM funcionarios
  UNION ALL
  SELECT d.supervisor,f.id_funcionario FROM descendentes d JOIN funcionarios f ON f.id_supervisor=d.descendente
) SELECT s.nome AS supervisor,COALESCE(SUM(v.valor_venda),0) AS total_equipe
  FROM descendentes d JOIN funcionarios s ON s.id_funcionario=d.supervisor
  LEFT JOIN vendas v ON v.id_funcionario=d.descendente GROUP BY s.id_funcionario,s.nome ORDER BY s.nome;
