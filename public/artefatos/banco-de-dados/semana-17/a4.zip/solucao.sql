USE agregacao_a2;
SELECT c.nome,
  (SELECT COALESCE(SUM(co.valor_total),0) FROM compras co WHERE co.cliente_id=c.cliente_id) AS total_compras
FROM clientes c;
SELECT DISTINCT c.nome FROM clientes c JOIN compras co ON co.cliente_id=c.cliente_id
WHERE co.valor_total > (SELECT AVG(valor_total) FROM compras);
SELECT totais.nome, totais.total_compras FROM (
  SELECT c.cliente_id,c.nome,SUM(co.valor_total) AS total_compras
  FROM clientes c JOIN compras co ON co.cliente_id=c.cliente_id GROUP BY c.cliente_id,c.nome
) AS totais
WHERE totais.total_compras > (
  SELECT AVG(t2.total_compras) FROM (
    SELECT SUM(valor_total) AS total_compras FROM compras GROUP BY cliente_id
  ) AS t2
);
