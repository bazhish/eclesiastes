DROP DATABASE IF EXISTS agregacao_a2;
CREATE DATABASE agregacao_a2 CHARACTER SET utf8mb4;
USE agregacao_a2;
CREATE TABLE clientes (cliente_id INT PRIMARY KEY,nome VARCHAR(100),email VARCHAR(150));
CREATE TABLE compras (compra_id INT PRIMARY KEY,cliente_id INT NOT NULL,valor_total DECIMAL(10,2) NOT NULL,data_compra DATE NOT NULL,
  FOREIGN KEY(cliente_id) REFERENCES clientes(cliente_id));
INSERT INTO clientes VALUES (1,'Ana','ana@exemplo.com'),(2,'Bruno','bruno@exemplo.com'),(3,'Carla','carla@exemplo.com');
INSERT INTO compras VALUES (1,1,100,'2024-09-02'),(2,1,250,'2024-09-20'),(3,2,80,'2024-09-25'),(4,3,500,'2024-10-01');
SELECT SUM(valor_total) AS valor_total_vendas FROM compras;
SELECT COUNT(DISTINCT cliente_id) AS clientes_unicos FROM compras;
SELECT AVG(valor_total) AS valor_medio_por_compra FROM compras;
SELECT COUNT(*) AS compras_setembro_2024 FROM compras
  WHERE data_compra >= '2024-09-01' AND data_compra < '2024-10-01';
