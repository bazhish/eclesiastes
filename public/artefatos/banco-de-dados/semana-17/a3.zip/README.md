# Como executar

- **Linguagem:** SQL para MySQL 8.0+
- **Dependências:** MySQL 8.0+ e um usuário com permissão para criar o banco, as tabelas e os objetos usados no arquivo.
- **Execução:** `mysql -u SEU_USUARIO -p < solucao.sql`
- **Teste:** execute as consultas `SELECT`, `EXPLAIN` ou verificações comentadas no próprio arquivo.
- **Resultado esperado:** criação de uma base de demonstração e retorno dos resultados descritos no gabarito. Use uma instância de teste, pois o script recria tabelas próprias.
