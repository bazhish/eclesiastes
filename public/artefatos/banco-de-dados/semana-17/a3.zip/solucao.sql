USE agregacao_a2;
SELECT c.nome,c.email,co.valor_total FROM clientes c
  INNER JOIN compras co ON co.cliente_id=c.cliente_id;
SELECT c.nome,c.email,co.valor_total FROM clientes c
  LEFT JOIN compras co ON co.cliente_id=c.cliente_id;
SELECT c.nome,c.email,co.compra_id,co.valor_total FROM clientes c
  RIGHT JOIN compras co ON co.cliente_id=c.cliente_id;
