# Execução

- **Linguagem:** JavaScript ES Modules; Node.js 20+.
- **Dependências:** nenhuma; não use credenciais reais.
- **Execução:** `node test_api_segura.js`.
- **Teste:** `node test_api_segura.js`.
- **Resultado esperado:** testes de autenticação, autorização e validação passam..
