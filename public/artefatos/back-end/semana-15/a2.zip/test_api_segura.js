import assert from "node:assert/strict"; import { autorizar } from "./api_segura.js";
assert.equal(autorizar({token:"x"},{produto:"Livro",quantidade:1}).status,401);
assert.equal(autorizar({token:"token-teste",papel:"usuario"},{produto:"Livro",quantidade:1}).status,201);
assert.equal(autorizar({token:"token-teste",papel:"usuario"},{produto:"Livro",quantidade:1,acao:"excluir"}).status,403);
console.log("API_SEGURA_OK");
