export function autorizar({ token, papel }, pedido) {
  if (token !== "token-teste") return { status: 401, erro: "não autenticado" };
  if (!pedido?.produto || !Number.isInteger(pedido.quantidade) || pedido.quantidade < 1) return { status: 400, erro: "dados inválidos" };
  if (pedido.acao === "excluir" && papel !== "admin") return { status: 403, erro: "sem permissão" };
  return { status: 201, pedido: { produto: pedido.produto, quantidade: pedido.quantidade } };
}
