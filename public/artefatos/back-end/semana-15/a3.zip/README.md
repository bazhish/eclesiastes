# Execução — testes de segurança simulados

- **Linguagem:** JavaScript ES Modules; Node.js 20+.
- **Dependências:** nenhuma; os testes são locais e autorizados.
- **Execução:** `node test_checklist_seguranca.js`.
- **Teste:** `node test_checklist_seguranca.js`.
- **Resultado esperado:** identifica rota sem autenticação, vazamento em log e detalhe interno exposto.
- **Limitação:** não executa varredura contra rede, sistema real ou serviço de terceiros.
