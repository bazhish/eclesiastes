import assert from "node:assert/strict";
import { avaliarResposta } from "./checklist_seguranca.js";

assert.deepEqual(avaliarResposta({ status: 401, autenticada: false, log: "acesso negado" }), []);
assert.equal(avaliarResposta({ status: 200, autenticada: false }).length, 1);
assert.equal(avaliarResposta({ status: 500, autenticada: true, log: "token=abc", corpo: "stack trace" }).length, 2);
console.log("CHECKLIST_SEGURANCA_OK");
