export function avaliarResposta(resposta) {
  const falhas = [];
  if (resposta.status === 200 && !resposta.autenticada) falhas.push("rota sensível aceitou requisição não autenticada");
  if (/token|senha|secret/i.test(String(resposta.log || ""))) falhas.push("log contém possível segredo");
  if (resposta.status === 500 && resposta.corpo?.includes("stack")) falhas.push("erro expõe detalhe interno");
  return falhas;
}
