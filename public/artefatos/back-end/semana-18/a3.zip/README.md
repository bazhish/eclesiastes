# Execução

- **Linguagem:** Python 3.11+.
- **Dependências:** nenhuma; não use credenciais reais.
- **Execução:** `python planejar_tarefas.py`.
- **Teste:** `python test_planejar_tarefas.py`.
- **Resultado esperado:** lista as três tarefas e os respectivos motores..
- **Limitação:** Não instala Celery nem cria cron real..
