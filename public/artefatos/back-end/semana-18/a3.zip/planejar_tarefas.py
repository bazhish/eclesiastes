def tarefas(): return [{"nome":"pagamentos_pendentes","quando":"diariamente 08:00","motor":"celery"},{"nome":"novos_cursos","quando":"semanalmente","motor":"celery"},{"nome":"limpar_acessos","quando":"mensalmente","motor":"cron"}]
if __name__ == "__main__":
    for tarefa in tarefas(): print(tarefa)
