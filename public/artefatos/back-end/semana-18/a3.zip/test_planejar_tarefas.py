import unittest
from planejar_tarefas import tarefas
class TestPlano(unittest.TestCase):
 def test_tres_tarefas(self): self.assertEqual(len(tarefas()),3)
if __name__=="__main__": unittest.main()
