# Execução — autenticação e autorização simuladas

- **Linguagem:** JavaScript ES Modules; Node.js 20+.
- **Dependências:** nenhuma; não há token ou chave real.
- **Execução:** `node test_autorizacao.js`.
- **Teste:** `node test_autorizacao.js`.
- **Resultado esperado:** token ausente retorna 401, escopo insuficiente retorna 403 e usuário titular autorizado retorna 200.
- **Limitação:** demonstra a regra de autorização; não implementa emissor OAuth ou assinatura JWT real.
