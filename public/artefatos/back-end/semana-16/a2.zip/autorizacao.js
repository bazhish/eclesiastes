export function conferirAcesso(token, recurso) {
  if (!token || token.expirado) return { status: 401 };
  if (!token.escopos?.includes(recurso.escopo)) return { status: 403 };
  if (recurso.titular !== token.sub && !token.papeis?.includes("admin")) return { status: 403 };
  return { status: 200 };
}
