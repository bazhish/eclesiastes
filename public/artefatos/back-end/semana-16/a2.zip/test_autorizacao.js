import assert from "node:assert/strict";
import { conferirAcesso } from "./autorizacao.js";
const recurso = { escopo: "contas:ler", titular: "u1" };
assert.equal(conferirAcesso(null, recurso).status, 401);
assert.equal(conferirAcesso({ sub: "u1", expirado: false, escopos: [] }, recurso).status, 403);
assert.equal(conferirAcesso({ sub: "u1", expirado: false, escopos: ["contas:ler"] }, recurso).status, 200);
console.log("AUTORIZACAO_OK");
