# Execução

- **Linguagem:** JavaScript ES Modules; Node.js 20+.
- **Dependências:** nenhuma; não use credenciais reais.
- **Execução:** `node test_cors.js`.
- **Teste:** `node test_cors.js`.
- **Resultado esperado:** apenas a origem confiável recebe cabeçalhos CORS..
