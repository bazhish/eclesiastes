# Execução

- **Linguagem:** JavaScript ES Modules; Node.js 20+.
- **Dependências:** nenhuma; não use credenciais reais.
- **Execução:** `node test_webhook_pagamento.js`.
- **Teste:** `node test_webhook_pagamento.js`.
- **Resultado esperado:** rejeita assinatura inválida, confirma evento aprovado e ignora duplicata..
- **Limitação:** Simulação local; não processa dinheiro nem chama API externa..
