# Execução

- **Linguagem:** JavaScript ES Modules; Node.js 20+.
- **Dependências:** nenhuma; não use credenciais reais.
- **Execução:** `node test_funcao_pagamento.js`.
- **Teste:** `node test_funcao_pagamento.js`.
- **Resultado esperado:** valida assinatura e processa somente evento confirmado..
- **Limitação:** Não é conexão com AWS Lambda nem provedor de pagamento..
