import crypto from "node:crypto";
export function validarEvento(corpo, assinatura, segredo="segredo-teste") { return crypto.timingSafeEqual(Buffer.from(crypto.createHmac("sha256",segredo).update(corpo).digest("hex")),Buffer.from(assinatura)); }
export function handler(evento) { if (!evento.assinaturaValida) return {statusCode:401}; if (evento.tipo!=="pagamento.confirmado") return {statusCode:202}; return {statusCode:200,body:"pagamento processado"}; }
