# Execução

- **Linguagem:** SQL genérico.
- **Dependências:** nenhuma; não use credenciais reais.
- **Execução:** `não executável sem SGBD configurado`.
- **Teste:** `revisão estática de privilégios`.
- **Resultado esperado:** o papel de recepção não recebe acesso ao prontuário..
- **Limitação:** Não há banco local; é uma simulação segura..
