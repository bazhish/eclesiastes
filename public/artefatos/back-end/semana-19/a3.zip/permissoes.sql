-- Exemplo: adaptar ao SGBD e ao modelo de dados real.
GRANT SELECT, INSERT, UPDATE ON agenda TO recepcao;
GRANT SELECT, INSERT, UPDATE ON prontuario TO medico;
REVOKE ALL ON prontuario FROM recepcao;
