# Execução

- **Linguagem:** YAML de GitHub Actions e JavaScript; Node.js 20+.
- **Dependências:** nenhuma; não use credenciais reais.
- **Execução:** `node --test`.
- **Teste:** `node --test`.
- **Resultado esperado:** teste local passa; o YAML é revisão estática e não executa deploy..
