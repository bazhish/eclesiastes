# Execução

- **Linguagem:** Configuração Nginx.
- **Dependências:** nenhuma; não use credenciais reais.
- **Execução:** `nginx -t -c nginx.conf`.
- **Teste:** `nginx -t -c nginx.conf`.
- **Resultado esperado:** a sintaxe é validada quando Nginx estiver instalado..
- **Limitação:** Nginx não está instalado no ambiente; validação é estática/simulada..
