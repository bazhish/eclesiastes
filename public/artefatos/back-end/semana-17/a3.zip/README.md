# Execução

- **Linguagem:** JSON de configuração; Node.js 20+ e Python 3.11+.
- **Dependências:** nenhuma; não use credenciais reais.
- **Execução:** `npm ci`.
- **Teste:** `npm test; python -m pip install -r requirements.txt`.
- **Resultado esperado:** arquivos de dependência documentam ambiente sem instalar pacotes automaticamente..
- **Limitação:** As versões devem ser revisadas antes da instalação em projeto real..
