# Execução

- **Linguagem:** JavaScript ES Modules; Node.js 20+.
- **Dependências:** nenhuma; não use credenciais reais.
- **Execução:** `node test_rotas_mock.js`.
- **Teste:** `node test_rotas_mock.js`.
- **Resultado esperado:** retorna rota simulada e valida parâmetros..
- **Limitação:** Integração real exige chave e contrato do provedor..
