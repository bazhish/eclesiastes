# Execução

- **Linguagem:** JavaScript ES Modules; Node.js 20+.
- **Dependências:** nenhuma; não use credenciais reais.
- **Execução:** `node test_logger.js`.
- **Teste:** `node test_logger.js`.
- **Resultado esperado:** gera JSON com correlação e classifica erro 5xx..
- **Limitação:** Não envia dados a Prometheus/Grafana/ELK reais..
