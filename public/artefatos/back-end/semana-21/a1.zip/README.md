# Execução

- **Linguagem:** JavaScript ES Modules; Node.js 20+.
- **Dependências:** nenhuma; não use credenciais reais.
- **Execução:** `node test_config.js`.
- **Teste:** `node test_config.js`.
- **Resultado esperado:** aceita configuração pública e rejeita segredo ausente em produção..
- **Limitação:** Não há cofre configurado; leitura é simulada..
