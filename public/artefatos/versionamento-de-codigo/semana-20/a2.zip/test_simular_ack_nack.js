import assert from "node:assert/strict";
import { processar } from "./simular_ack_nack.js";
assert.equal(processar({ pedidoId: "1" }).acao, "ACK");
assert.equal(processar({ pedidoId: "2", falhaTemporaria: true }).acao, "NACK_RETRY");
assert.equal(processar({ pedidoId: "3", falhaTemporaria: true }, 3).acao, "DLQ");
assert.equal(processar({ pedidoId: "4", invalida: true }).acao, "DLQ");
console.log("TESTES_ACK_NACK_OK");
