# Execução — ACK, NACK e DLQ

- **Linguagem:** JavaScript ES Modules; Node.js 20+.
- **Dependências:** nenhuma.
- **Execução:** `node simular_ack_nack.js`.
- **Teste:** `node test_simular_ack_nack.js`.
- **Resultado esperado:** um ACK, um NACK com nova tentativa e uma mensagem em DLQ. A execução é uma simulação local, sem broker instalado.
