export function processar(mensagem, tentativa = 1, limite = 3) {
  if (mensagem.invalida) return { acao: "DLQ", tentativa, motivo: "mensagem inválida" };
  if (mensagem.falhaTemporaria && tentativa < limite) return { acao: "NACK_RETRY", tentativa, proximaTentativa: tentativa + 1 };
  if (mensagem.falhaTemporaria) return { acao: "DLQ", tentativa, motivo: "limite de tentativas" };
  return { acao: "ACK", tentativa, pedido: mensagem.pedidoId };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  console.log(processar({ pedidoId: "P-10" }));
  console.log(processar({ pedidoId: "P-11", falhaTemporaria: true }));
  console.log(processar({ pedidoId: "P-12", invalida: true }));
}
