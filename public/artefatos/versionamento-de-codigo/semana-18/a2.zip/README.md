# Execução — SemVer

- **Linguagem:** Python 3.11+.
- **Dependências:** nenhuma.
- **Execução:** `python -c "from semver import proxima_versao; print(proxima_versao('1.2.3', 'patch'))"`.
- **Teste:** `python -m unittest test_semver.py`.
- **Resultado esperado:** `1.2.3` evolui para `1.2.4`, `1.3.0` e `2.0.0` conforme o tipo.
