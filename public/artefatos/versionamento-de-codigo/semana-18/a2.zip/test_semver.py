import unittest
from semver import proxima_versao
class TestSemVer(unittest.TestCase):
    def test_fluxo(self):
        self.assertEqual(proxima_versao("1.2.3", "patch"), "1.2.4")
        self.assertEqual(proxima_versao("1.2.4", "minor"), "1.3.0")
        self.assertEqual(proxima_versao("1.3.0", "major"), "2.0.0")
if __name__ == "__main__": unittest.main()
