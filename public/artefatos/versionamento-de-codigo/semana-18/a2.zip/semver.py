def proxima_versao(versao: str, tipo: str) -> str:
    major, minor, patch = map(int, versao.split("."))
    if tipo == "patch": return f"{major}.{minor}.{patch + 1}"
    if tipo == "minor": return f"{major}.{minor + 1}.0"
    if tipo == "major": return f"{major + 1}.0.0"
    raise ValueError("Tipo deve ser patch, minor ou major.")
