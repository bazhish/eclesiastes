def calcular_total(valor: float, taxa: float) -> float:
    if valor < 0:
        return 0
    total = valor + (valor * taxa)
    print(f"Total calculado: {total}")
    return total
