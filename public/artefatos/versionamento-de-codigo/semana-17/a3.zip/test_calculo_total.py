import unittest
from calculo_total import calcular_total

class TestCalculoTotal(unittest.TestCase):
    def test_total_positivo(self): self.assertEqual(calcular_total(100, 0.1), 110)
    def test_valor_negativo(self): self.assertEqual(calcular_total(-1, 0.1), 0)

if __name__ == "__main__": unittest.main()
