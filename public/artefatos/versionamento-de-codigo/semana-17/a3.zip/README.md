# Execução — resolução de conflito

- **Linguagem:** Python 3.11+.
- **Dependências:** nenhuma.
- **Execução:** `python -c "from calculo_total import calcular_total; print(calcular_total(100, 0.1))"`.
- **Teste:** `python -m unittest test_calculo_total.py`.
- **Resultado esperado:** valor 100 com taxa 0,1 retorna 110; valor negativo retorna 0.
