def calcular_media(notas: list[float]) -> float:
    if not notas:
        raise ValueError("A lista de notas não pode estar vazia.")
    return sum(notas) / len(notas)


if __name__ == "__main__":
    print(calcular_media([7, 8, 6, 10, 5]))
