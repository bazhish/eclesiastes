import unittest
from media_notas import calcular_media

class TestMedia(unittest.TestCase):
    def test_media(self): self.assertEqual(calcular_media([7, 8, 6, 10, 5]), 7.2)
    def test_lista_vazia(self):
        with self.assertRaises(ValueError): calcular_media([])

if __name__ == "__main__": unittest.main()
