# Execução — Code Review

- **Linguagem:** Python 3.11+.
- **Dependências:** nenhuma.
- **Execução:** `python media_notas.py`.
- **Teste:** `python -m unittest test_media_notas.py`.
- **Resultado esperado:** execução imprime `7.2`; os testes validam lista preenchida e lista vazia.
