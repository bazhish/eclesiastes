$ErrorActionPreference = "Stop"
$base = Join-Path $PSScriptRoot "cenario-git"
if (Test-Path -LiteralPath $base) { Remove-Item -LiteralPath $base -Recurse -Force }
New-Item -ItemType Directory -Path $base | Out-Null
Push-Location $base
try {
  git init -q; git config user.name "Equipe de Manutenção"; git config user.email "equipe@example.test"
  Set-Content calculo_dosagem.js 'console.log("cálculo correto")' -Encoding utf8
  git add calculo_dosagem.js; git commit -qm "feat: implementa cálculo base de dosagem"; $estavel = git rev-parse HEAD
  Set-Content layout.css 'body { color: black; }' -Encoding utf8
  git add layout.css; git commit -qm "style: adiciona layout"; $layout = git rev-parse HEAD
  Set-Content calculo_dosagem.js 'console.log("cálculo incorreto")' -Encoding utf8
  git add calculo_dosagem.js; git commit -qm "update: ajuste na função"
  Remove-Item layout.css; git add -A; git commit -qm "delete: remove arquivos antigos"
  git restore --source $estavel -- calculo_dosagem.js; git restore --source $layout -- layout.css
  if ((Get-Content calculo_dosagem.js -Raw) -notmatch "correto" -or -not (Test-Path layout.css)) { throw "Recuperação não confirmada." }
  git add calculo_dosagem.js layout.css; git commit -qm "fix: restaura cálculo de dosagem e layout removido por engano"
  git log --oneline -5; Write-Output "CENARIO_VALIDADO"
} finally { Pop-Location }
