# Execução — cenário Git

- **Linguagem:** PowerShell 7+; Git 2.x.
- **Dependências:** Git disponível no PATH; nenhuma instalação de pacote.
- **Execução:** `pwsh -File executar_cenario.ps1`.
- **Teste:** o próprio script confere a recuperação de `calculo_dosagem.js` e `layout.css`.
- **Resultado esperado:** cinco commits exibidos e a linha `CENARIO_VALIDADO`.
