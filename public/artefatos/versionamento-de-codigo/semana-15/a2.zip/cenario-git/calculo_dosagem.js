console.log("cálculo correto")
