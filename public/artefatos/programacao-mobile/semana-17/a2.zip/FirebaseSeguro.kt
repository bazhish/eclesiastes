// Simulação didática sem credenciais reais.
class FirebaseSeguro {
    fun executar(entrada: String): String {
        require(entrada.isNotBlank()) { "Entrada obrigatória" }
        return "Operação validada localmente: $entrada"
    }
}
fun main() { println(FirebaseSeguro().executar("teste")) }
