// Simulação didática sem credenciais reais.
class ProtecaoDados {
    fun executar(entrada: String): String {
        require(entrada.isNotBlank()) { "Entrada obrigatória" }
        return "Operação validada localmente: $entrada"
    }
}
fun main() { println(ProtecaoDados().executar("teste")) }
