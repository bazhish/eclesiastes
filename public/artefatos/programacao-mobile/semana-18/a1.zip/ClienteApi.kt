// Simulação didática sem credenciais reais.
class ClienteApi {
    fun executar(entrada: String): String {
        require(entrada.isNotBlank()) { "Entrada obrigatória" }
        return "Operação validada localmente: $entrada"
    }
}
fun main() { println(ClienteApi().executar("teste")) }
