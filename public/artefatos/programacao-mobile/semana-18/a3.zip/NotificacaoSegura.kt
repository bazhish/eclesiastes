// Simulação didática sem credenciais reais.
class NotificacaoSegura {
    fun executar(entrada: String): String {
        require(entrada.isNotBlank()) { "Entrada obrigatória" }
        return "Operação validada localmente: $entrada"
    }
}
fun main() { println(NotificacaoSegura().executar("teste")) }
