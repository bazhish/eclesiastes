// Simulação didática sem credenciais reais.
class AcessibilidadeReceita {
    fun executar(entrada: String): String {
        require(entrada.isNotBlank()) { "Entrada obrigatória" }
        return "Operação validada localmente: $entrada"
    }
}
fun main() { println(AcessibilidadeReceita().executar("teste")) }
