// Simulação didática sem credenciais reais.
class InterfaceAdaptativa {
    fun executar(entrada: String): String {
        require(entrada.isNotBlank()) { "Entrada obrigatória" }
        return "Operação validada localmente: $entrada"
    }
}
fun main() { println(InterfaceAdaptativa().executar("teste")) }
