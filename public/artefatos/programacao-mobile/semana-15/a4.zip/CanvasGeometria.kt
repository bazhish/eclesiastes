// Simulação didática sem credenciais reais.
class CanvasGeometria {
    fun executar(entrada: String): String {
        require(entrada.isNotBlank()) { "Entrada obrigatória" }
        return "Operação validada localmente: $entrada"
    }
}
fun main() { println(CanvasGeometria().executar("teste")) }
