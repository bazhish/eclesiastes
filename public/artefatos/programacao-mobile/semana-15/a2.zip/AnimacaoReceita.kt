// Simulação didática sem credenciais reais.
class AnimacaoReceita {
    fun executar(entrada: String): String {
        require(entrada.isNotBlank()) { "Entrada obrigatória" }
        return "Operação validada localmente: $entrada"
    }
}
fun main() { println(AnimacaoReceita().executar("teste")) }
