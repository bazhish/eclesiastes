// Simulação didática sem credenciais reais.
class StoreTarefas {
    fun executar(entrada: String): String {
        require(entrada.isNotBlank()) { "Entrada obrigatória" }
        return "Operação validada localmente: $entrada"
    }
}
fun main() { println(StoreTarefas().executar("teste")) }
