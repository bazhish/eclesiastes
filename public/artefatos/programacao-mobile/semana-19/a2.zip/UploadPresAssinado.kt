// Simulação didática sem credenciais reais.
class UploadPresAssinado {
    fun executar(entrada: String): String {
        require(entrada.isNotBlank()) { "Entrada obrigatória" }
        return "Operação validada localmente: $entrada"
    }
}
fun main() { println(UploadPresAssinado().executar("teste")) }
