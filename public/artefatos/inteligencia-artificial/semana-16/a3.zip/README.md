# Código — Fluxo básico de ML

## Linguagem e versão

Python 3.11+.

## Dependências

`scikit-learn>=1.4`.

## Instalação e execução

`python -m pip install scikit-learn` e `python modelo.py`.

## Teste

O script fixa `random_state=42` para tornar a divisão reproduzível.

## Resultado esperado

São impressas previsões e acurácia; o valor é apenas demonstrativo para a pequena amostra.
