from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

X = [[2, 1], [4, 0], [1, 3], [3, 1], [5, 0], [2, 2]]
y = [0, 1, 0, 1, 1, 0]
X_treino, X_teste, y_treino, y_teste = train_test_split(X, y, test_size=0.33, random_state=42, stratify=y)
modelo = LogisticRegression(random_state=42)
modelo.fit(X_treino, y_treino)
previsoes = modelo.predict(X_teste)
print('previsões:', previsoes.tolist())
print('acurácia:', accuracy_score(y_teste, previsoes))
