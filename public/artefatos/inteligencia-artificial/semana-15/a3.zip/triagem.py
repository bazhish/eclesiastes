def triagem_simbolica(queixa):
    texto = queixa.lower()
    if any(palavra in texto for palavra in ('sangue', 'desmaio', 'respirar')):
        return 'ALTA: procure atendimento de emergência.'
    if any(palavra in texto for palavra in ('febre', 'dor forte')):
        return 'MÉDIA: procure atendimento no mesmo dia.'
    if any(palavra in texto for palavra in ('dor', 'incômodo')):
        return 'BAIXA: observe os sintomas e procure orientação se piorar.'
    return 'INDEFINIDA: encaminhe para avaliação humana.'

for frase in [
    'Minha cabeça dói um pouco.',
    'Sinto pressão no peito e falta de ar.',
    'Não consigo puxar o ar e minha visão escureceu.',
]:
    print(f'{frase} => {triagem_simbolica(frase)}')
