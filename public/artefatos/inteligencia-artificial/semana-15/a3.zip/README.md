# Código — Triagem simbólica

## Linguagem e versão

Python 3.11+.

## Dependências

Nenhuma.

## Execução

`python triagem.py`.

## Teste

Execute as três frases já incluídas.

## Resultado esperado

O terceiro caso expõe a limitação de correspondência literal e é encaminhado como indefinido. É uma simulação educativa, não um sistema médico.
