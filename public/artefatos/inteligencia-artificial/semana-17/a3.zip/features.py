import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
np.random.seed(42)
dados=pd.DataFrame({'horas_estudo':np.random.randint(1,6,50),'exercicios':np.random.randint(10,100,50),'frequencia':np.random.randint(60,100,50),'participacao':np.random.randint(1,10,50)})
dados['nota_anterior']=dados.horas_estudo*1.5+np.random.normal(0,1,50)
dados['engajamento_total']=dados.frequencia+dados.participacao
print(dados.corr(numeric_only=True).round(2))
pca=PCA(n_components=.95,random_state=42).fit(dados.drop(columns='nota_anterior'))
print('componentes:',pca.n_components_,'variância:',pca.explained_variance_ratio_.sum())
