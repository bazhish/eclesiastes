# Código — Engenharia de atributos

## Linguagem e versão

Python 3.11+.

## Dependências

`numpy`, `pandas` e `scikit-learn`.

## Instalação e execução

`python -m pip install numpy pandas scikit-learn` e `python features.py`.

## Teste

Confira a matriz de correlação e a variância explicada.

## Resultado esperado

O script mostra a relação entre variáveis e o número de componentes necessário para manter 95% da variância.
